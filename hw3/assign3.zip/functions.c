#include "functions.h"

#include <stdio.h>
#include <string.h>

int test(int size){
  return 0;
}

