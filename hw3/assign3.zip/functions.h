#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__
#include <stdio.h>


/** Function description
 *  Parameters:
 *  int Int
 *  Return: 0 if no issues, 1 if there are issues.
 */
int test(int size);

#endif // __FUNCTIONS_H__
